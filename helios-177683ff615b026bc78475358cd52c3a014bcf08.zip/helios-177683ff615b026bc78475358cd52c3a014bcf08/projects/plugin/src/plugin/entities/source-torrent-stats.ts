export interface SourceTorrentStats {
  providerName: string,
  torrents: number
}
