export interface RealDebridTorrentsAddMagnetDto {
  id: string;
  uri: string;
}
