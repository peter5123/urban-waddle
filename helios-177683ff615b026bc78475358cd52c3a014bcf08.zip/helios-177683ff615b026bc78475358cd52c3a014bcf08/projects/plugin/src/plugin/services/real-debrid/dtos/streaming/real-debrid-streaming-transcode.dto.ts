export interface RealDebridStreamingTranscodeDto {
  apple: {
    full: string;
  };
  dash: {
    full: string;
  };
  liveMP4: {
    full: string;
  };
  h264WebM: {
    full: string;
  };
}
