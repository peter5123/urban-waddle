export interface BaseDto<T> {
  data: T;
  errors: any
}
