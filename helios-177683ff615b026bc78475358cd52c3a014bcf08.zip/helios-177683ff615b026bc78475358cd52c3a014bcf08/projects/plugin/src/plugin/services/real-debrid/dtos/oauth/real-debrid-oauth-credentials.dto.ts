export interface RealDebridOauthCredentialsDto {
  client_id: string;
  client_secret: string;
}
