export interface Link {
  filename: string;
  size: number;
  url: string;
  streamLink: string;
  servicePlayerUrl: string;
}
