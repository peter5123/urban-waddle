export interface EpisodeDto {
  absoluteNumber: number;
}
