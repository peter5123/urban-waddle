export declare type SourceQuality = '2160p' | '1080p' | '720p' | 'other';
