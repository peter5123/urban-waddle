export interface AllDebridErrorDto {
  code: string;
  message: string;
}
