export interface LastPlayedSource {
  id: string;
  title: string;
  provider: string;
  showTraktId?: number;
}
