export interface TmdbEpisodeDto {
  air_date: string;
  episode_number: number;
  id: number;
  name: string
  overview: string
  production_code: number;
  season_number: number;
  show_id: number;
}
